#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <Windows.h>
#include <Psapi.h>
#include <d3d11.h>
#include <dxgi.h>
#include <cstdio>
#include <cstdint>
#include <cstdarg>
#include <cstring>
#include <cmath>
#include <string>
#include <algorithm>

#include "imgui/imgui.h"
#include "imgui/imgui_impl_dx11.h"
#include "imgui/imgui_impl_win32.h"
#include "minhook/include/MinHook.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "Psapi.lib")

// ============================================================
// cs2-dumper offsets (2026-11-20)
// ============================================================
namespace offsets {
    constexpr std::ptrdiff_t dwEntityList              = 0x270D5B0;
    constexpr std::ptrdiff_t dwLocalPlayerController    = 0x252F300;
    constexpr std::ptrdiff_t dwLocalPlayerPawn          = 0x2557AB8;
    constexpr std::ptrdiff_t dwViewMatrix               = 0x255D3D0;
    constexpr std::ptrdiff_t dwViewAngles               = 0x256DBE8;
    constexpr std::ptrdiff_t dwCSGOInput                = 0x256D560;
    constexpr std::ptrdiff_t dwGlobalVars               = 0x2223AD0;
}

namespace netvars {
    // C_BaseEntity
    constexpr std::ptrdiff_t m_iHealth          = 0x34C;
    constexpr std::ptrdiff_t m_lifeState         = 0x354;
    constexpr std::ptrdiff_t m_iTeamNum          = 0x3E7;
    constexpr std::ptrdiff_t m_pGameSceneNode    = 0x330;
    constexpr std::ptrdiff_t m_fFlags            = 0x3F4;

    // CGameSceneNode
    constexpr std::ptrdiff_t m_vecAbsOrigin      = 0xC8;
    constexpr std::ptrdiff_t m_bDormant          = 0x103;

    // CSkeletonInstance (inherits CGameSceneNode)
    constexpr std::ptrdiff_t m_modelState        = 0x140;
    constexpr std::ptrdiff_t m_boneArray         = 0x80; // CModelState'ten bone array pointer

    // C_BasePlayerPawn
    constexpr std::ptrdiff_t m_vecViewOffset      = 0xF60;
    constexpr std::ptrdiff_t m_vOldOrigin         = 0x14A4;

    // CCSPlayerController
    constexpr std::ptrdiff_t m_hPlayerPawn        = 0x92C;
    constexpr std::ptrdiff_t m_sSanitizedPlayerName = 0x878;
    constexpr std::ptrdiff_t m_iPawnHealth        = 0x938;
    constexpr std::ptrdiff_t m_bPawnIsAlive       = 0x934;

    // CBasePlayerController
    constexpr std::ptrdiff_t m_hPawn              = 0x6BC;

    // C_CSPlayerPawn
    constexpr std::ptrdiff_t m_entitySpottedState = 0x1EB8;
    constexpr std::ptrdiff_t m_iShotsFired        = 0x1EE8;
    constexpr std::ptrdiff_t m_ArmorValue         = 0x1F00;
    constexpr std::ptrdiff_t m_angEyeAngles       = 0x3630;
    constexpr std::ptrdiff_t m_bIsScoped           = 0x1ED0;
    constexpr std::ptrdiff_t m_pAimPunchServices   = 0x1598;

    // C_BaseModelEntity -> CGlowProperty
    constexpr std::ptrdiff_t m_Glow               = 0xDE8;
    constexpr std::ptrdiff_t m_iGlowType          = 0x30;
    constexpr std::ptrdiff_t m_glowColorOverride  = 0x40;
    constexpr std::ptrdiff_t m_bGlowing           = 0x51;

    // EntitySpottedState_t
    constexpr std::ptrdiff_t m_bSpottedByMask     = 0xC;
    constexpr std::ptrdiff_t m_bSpotted           = 0x8;

    // CCSPlayer_AimPunchServices
    constexpr std::ptrdiff_t m_unpredictableBaseAngle = 0xA4;
}

// ============================================================
// math
// ============================================================
struct Vec3 {
    float x, y, z;
    Vec3() : x(0), y(0), z(0) {}
    Vec3(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
    Vec3 operator+(const Vec3& o) const { return { x + o.x, y + o.y, z + o.z }; }
    Vec3 operator-(const Vec3& o) const { return { x - o.x, y - o.y, z - o.z }; }
    Vec3 operator*(float s) const { return { x * s, y * s, z * s }; }
    float length() const { return sqrtf(x * x + y * y + z * z); }
    float length2D() const { return sqrtf(x * x + y * y); }
    bool isZero() const { return x == 0.f && y == 0.f && z == 0.f; }
};

struct ViewMatrix_t {
    float m[4][4];
};

static bool WorldToScreen(const Vec3& world, const ViewMatrix_t& vm, Vec3& screen, float screenW, float screenH) {
    float w = vm.m[3][0] * world.x + vm.m[3][1] * world.y + vm.m[3][2] * world.z + vm.m[3][3];
    if (w < 0.001f) return false;
    float invW = 1.0f / w;
    screen.x = (screenW * 0.5f) + (vm.m[0][0] * world.x + vm.m[0][1] * world.y + vm.m[0][2] * world.z + vm.m[0][3]) * invW * screenW * 0.5f;
    screen.y = (screenH * 0.5f) - (vm.m[1][0] * world.x + vm.m[1][1] * world.y + vm.m[1][2] * world.z + vm.m[1][3]) * invW * screenH * 0.5f;
    return true;
}

constexpr float DEG2RAD = 3.14159265358979323846f / 180.0f;
constexpr float RAD2DEG = 180.0f / 3.14159265358979323846f;

static void ClampAngles(Vec3& angles) {
    if (angles.x > 89.0f) angles.x = 89.0f;
    if (angles.x < -89.0f) angles.x = -89.0f;
    while (angles.y > 180.0f) angles.y -= 360.0f;
    while (angles.y < -180.0f) angles.y += 360.0f;
    angles.z = 0.0f;
}

static Vec3 CalcAngle(const Vec3& src, const Vec3& dst) {
    Vec3 delta = dst - src;
    float hyp = delta.length2D();
    if (hyp < 0.001f) return {};
    Vec3 angles;
    angles.x = -atanf(delta.z / hyp) * RAD2DEG;
    angles.y = atan2f(delta.y, delta.x) * RAD2DEG;
    angles.z = 0.0f;
    ClampAngles(angles);
    return angles;
}

static float GetFov(const Vec3& viewAngles, const Vec3& aimAngles) {
    Vec3 delta;
    delta.x = aimAngles.x - viewAngles.x;
    delta.y = aimAngles.y - viewAngles.y;
    if (delta.y > 180.0f) delta.y -= 360.0f;
    if (delta.y < -180.0f) delta.y += 360.0f;
    return sqrtf(delta.x * delta.x + delta.y * delta.y);
}

// ============================================================
// memory helpers (internal - SEH korumalÄ±)
// ============================================================
static bool IsValidPtr(uintptr_t addr) {
    if (addr < 0x10000 || addr > 0x7FFFFFFFFFFF) return false;
    return !IsBadReadPtr((void*)addr, sizeof(void*));
}

template<typename T>
static T Read(uintptr_t addr) {
    if (!IsValidPtr(addr)) return T{};
    __try {
        return *reinterpret_cast<T*>(addr);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return T{};
    }
}

template<typename T>
static void Write(uintptr_t addr, const T& value) {
    if (!IsValidPtr(addr)) return;
    __try {
        *reinterpret_cast<T*>(addr) = value;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
}

// ============================================================
// tipler
// ============================================================
using PresentFn = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT);
using ResizeBuffersFn = HRESULT(__stdcall*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
using ClipCursorFn = BOOL(__stdcall*)(const RECT*);

static PresentFn       g_origPresent = nullptr;
static ResizeBuffersFn g_origResizeBuffers = nullptr;
static ClipCursorFn    g_origClipCursor = nullptr;

static HWND                     g_window = nullptr;
static WNDPROC                  g_origWndProc = nullptr;
static ID3D11Device*            g_device = nullptr;
static ID3D11DeviceContext*     g_context = nullptr;
static ID3D11RenderTargetView*  g_rtv = nullptr;
static bool                     g_imguiReady = false;
static bool                     g_menuVisible = true;

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

// ============================================================
// ayarlar
// ============================================================
struct Settings {
    // ESP
    bool espEnabled = true;
    bool espBox = true;
    bool espName = true;
    bool espHealth = true;
    bool espHealthBar = true;
    bool espArmor = false;
    bool espSnaplines = false;
    bool espTeamCheck = true;
    float espBoxColor[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
    float espTeamColor[4] = { 0.0f, 0.4f, 1.0f, 1.0f };
    float espNameColor[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

    // ESP ekstra
    bool espRainbow = false;
    float rainbowSpeed = 0.5f;
    bool espVisColors = true;          // gorunen/gizli renk
    float espVisibleColor[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
    float espHiddenColor[4]  = { 1.0f, 0.0f, 0.0f, 1.0f };

    // Chams (iskelet dolgu silueti)
    bool chamsEnabled = false;
    bool chamsRainbow = false;
    float chamsAlpha = 0.55f;

    // Glow
    bool glowEnabled = false;
    bool glowRainbow = false;
    bool glowTeammates = true;         // takim arkadaslarina da glow
    float glowTeamColor[4] = { 0.2f, 0.5f, 1.0f, 1.0f };

    // Aimbot FOV cemberi
    bool aimbotDrawFov = true;
    bool fovRainbow = false;
    bool fovFilled = false;
    float fovColor[4] = { 1.0f, 1.0f, 1.0f, 0.8f };
    float fovLockedColor[4] = { 0.0f, 1.0f, 0.2f, 1.0f };

    // Aimbot
    bool aimbotEnabled = true;
    bool aimbotRequireKey = false;     // false = tus yok, FOV'a girene kilitlenir
    bool aimbotVisCheck = true;        // duvar arkasina kilitlenme
    int aimbotKey = VK_LMENU;
    float aimbotFov = 5.0f;
    float aimbotSmooth = 5.0f;
    bool aimbotRCS = true;
    int aimbotBone = 6;
    bool aimbotTeamCheck = true;

    // Debug
    bool showDebug = true;
} g_settings;

// Debug sayaÃ§larÄ±
static int g_dbgPlayersFound = 0;
static int g_dbgPlayersDrawn = 0;
static int g_dbgFailReason = 0; // 0=ok, 1=no entitylist, 2=no localplayer, 3=no controller, etc.
static char g_dbgLastError[128] = "Baslatiliyor...";

// ============================================================
// log
// ============================================================
static FILE* g_log = nullptr;

static void OpenLog() {
    char path[MAX_PATH]{};
    DWORD n = GetTempPathA(MAX_PATH, path);
    if (n == 0 || n >= MAX_PATH) return;
    strcat_s(path, "cs2int.log");
    fopen_s(&g_log, path, "w");
}

static void Log(const char* fmt, ...) {
    if (!g_log) return;
    va_list ap; va_start(ap, fmt);
    vfprintf(g_log, fmt, ap);
    va_end(ap);
    fputc('\n', g_log);
    fflush(g_log);
}

// ============================================================
// wndproc
// ============================================================
static LRESULT __stdcall hkWndProc(HWND hWnd, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_KEYDOWN && wp == VK_INSERT) {
        g_menuVisible = !g_menuVisible;
        if (g_imguiReady) ImGui::GetIO().ClearInputKeys();
        if (g_menuVisible) ReleaseCapture();
        return CallWindowProcA(g_origWndProc, hWnd, msg, wp, lp);
    }

    switch (msg) {
    case WM_ACTIVATE: case WM_ACTIVATEAPP: case WM_NCACTIVATE:
    case WM_SETFOCUS: case WM_KILLFOCUS:
    case WM_SYSCOMMAND: case WM_SIZE: case WM_MOVE:
    case WM_WINDOWPOSCHANGED: case WM_PAINT: case WM_ERASEBKGND:
    case WM_SETCURSOR:
        return CallWindowProcA(g_origWndProc, hWnd, msg, wp, lp);
    }

    if (g_menuVisible && g_imguiReady) {
        ImGuiIO& io = ImGui::GetIO();
        switch (msg) {
        case WM_MOUSEMOVE:
        case WM_LBUTTONDOWN: case WM_LBUTTONUP:
        case WM_RBUTTONDOWN: case WM_RBUTTONUP:
        case WM_MBUTTONDOWN: case WM_MBUTTONUP:
        case WM_MOUSEWHEEL:  case WM_MOUSEHWHEEL:
            ImGui_ImplWin32_WndProcHandler(hWnd, msg, wp, lp);
            if (io.WantCaptureMouse) return 1;
            break;
        case WM_KEYDOWN: case WM_KEYUP: case WM_CHAR:
        case WM_SYSKEYDOWN: case WM_SYSKEYUP:
            ImGui_ImplWin32_WndProcHandler(hWnd, msg, wp, lp);
            if (io.WantCaptureKeyboard) return 1;
            break;
        }
    }
    return CallWindowProcA(g_origWndProc, hWnd, msg, wp, lp);
}

// ============================================================
// rtv
// ============================================================
static void CreateRenderTarget(IDXGISwapChain* sc) {
    ID3D11Texture2D* back = nullptr;
    HRESULT hr = sc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&back);
    if (FAILED(hr) || !back) return;
    hr = g_device->CreateRenderTargetView(back, nullptr, &g_rtv);
    back->Release();
}

static void ReleaseRenderTarget() {
    if (g_rtv) { g_rtv->Release(); g_rtv = nullptr; }
}

// ============================================================
// imgui init
// ============================================================
static void InitImGui(IDXGISwapChain* sc) {
    if (FAILED(sc->GetDevice(__uuidof(ID3D11Device), (void**)&g_device)) || !g_device) return;
    g_device->GetImmediateContext(&g_context);

    DXGI_SWAP_CHAIN_DESC desc{};
    sc->GetDesc(&desc);
    g_window = desc.OutputWindow;

    g_origWndProc = (WNDPROC)SetWindowLongPtrA(g_window, GWLP_WNDPROC, (LONG_PTR)hkWndProc);
    CreateRenderTarget(sc);

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui::StyleColorsDark();

    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 8.0f;
    style.FrameRounding = 4.0f;
    style.GrabRounding = 4.0f;
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.08f, 0.08f, 0.12f, 0.94f);
    style.Colors[ImGuiCol_TitleBg] = ImVec4(0.15f, 0.05f, 0.25f, 1.0f);
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.25f, 0.08f, 0.45f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.15f, 0.15f, 0.22f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.6f, 0.2f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.6f, 0.2f, 1.0f, 1.0f);

    ImGui_ImplWin32_Init(g_window);
    ImGui_ImplDX11_Init(g_device, g_context);

    g_imguiReady = true;
    Log("[+] imgui hazir");
}

// ============================================================
// entity system
// ============================================================
static uintptr_t g_clientBase = 0;

static uintptr_t GetEntityByIndex(uintptr_t entityList, int index) {
    if (!entityList) return 0;

    // CS2 entity list: chunked array, her chunk 512 entity
    int chunkIndex = (index & 0x7FFF) >> 9;
    int indexInChunk = index & 0x1FF;

    uintptr_t chunkPtr = Read<uintptr_t>(entityList + 0x8 * (uint64_t)chunkIndex + 0x10);
    if (!chunkPtr) return 0;

    return Read<uintptr_t>(chunkPtr + 0x70 * (uint64_t)indexInChunk);
}

static Vec3 GetBonePos(uintptr_t pawn, int boneIndex) {
    uintptr_t gameSceneNode = Read<uintptr_t>(pawn + netvars::m_pGameSceneNode);
    if (!gameSceneNode) return {};

    // CSkeletonInstance -> m_modelState(0x140) -> boneArray(0x80)
    uintptr_t boneArrayPtr = Read<uintptr_t>(gameSceneNode + netvars::m_modelState + netvars::m_boneArray);
    if (!boneArrayPtr || !IsValidPtr(boneArrayPtr)) return {};

    // Her bone = 32 byte: {float x, float y, float z, float scale, quat rotation}
    Vec3 pos;
    pos.x = Read<float>(boneArrayPtr + boneIndex * 32 + 0);
    pos.y = Read<float>(boneArrayPtr + boneIndex * 32 + 4);
    pos.z = Read<float>(boneArrayPtr + boneIndex * 32 + 8);
    return pos;
}

static Vec3 GetEntityOrigin(uintptr_t pawn) {
    uintptr_t sceneNode = Read<uintptr_t>(pawn + netvars::m_pGameSceneNode);
    if (!sceneNode) return {};
    return Read<Vec3>(sceneNode + netvars::m_vecAbsOrigin);
}

static Vec3 GetHeadPos(uintptr_t pawn) {
    // Ã–nce bone'dan dene
    Vec3 boneHead = GetBonePos(pawn, 6);
    if (!boneHead.isZero() && fabsf(boneHead.z) > 1.0f) {
        return boneHead;
    }

    // Bone yoksa origin + viewOffset kullan
    Vec3 origin = GetEntityOrigin(pawn);
    Vec3 viewOffset = Read<Vec3>(pawn + netvars::m_vecViewOffset);
    return origin + viewOffset;
}

// ============================================================
// ViewAngles oku/yaz â€” CSGOInput Ã¼zerinden
// ============================================================
static ImVec4 Rainbow(float speed, float offset = 0.0f) {
    float t = (float)(GetTickCount64() % 100000ULL) / 1000.0f;
    float h = fmodf(t * speed + offset, 1.0f);
    float r, g, b;
    ImGui::ColorConvertHSVtoRGB(h, 1.0f, 1.0f, r, g, b);
    return ImVec4(r, g, b, 1.0f);
}

// Local oyuncunun controller index'i (spotted mask bit'i icin)
static int GetLocalIndex(uintptr_t entityList, uintptr_t localController) {
    for (int i = 1; i <= 64; i++)
        if (GetEntityByIndex(entityList, i) == localController) return i;
    return -1;
}

// Motorun kendi gorunurluk bilgisi: dusman pawn'i local tarafindan gorunuyor mu
static bool IsVisibleTo(uintptr_t pawn, int localIndex) {
    if (localIndex < 1) return true; // bulunamazsa engelleme
    uint32_t mask = Read<uint32_t>(pawn + netvars::m_entitySpottedState + netvars::m_bSpottedByMask);
    return (mask & (1u << (localIndex - 1))) != 0;
}

static void SetGlow(uintptr_t pawn, bool on, const ImVec4& c) {
    uintptr_t glow = pawn + netvars::m_Glow;
    if (on) {
        uint32_t col = (uint32_t)(c.x * 255.f) | ((uint32_t)(c.y * 255.f) << 8) |
                       ((uint32_t)(c.z * 255.f) << 16) | (255u << 24);
        Write<uint32_t>(glow + netvars::m_glowColorOverride, col);
        Write<int>(glow + netvars::m_iGlowType, 3);
        Write<bool>(glow + netvars::m_bGlowing, true);
    } else {
        Write<bool>(glow + netvars::m_bGlowing, false);
    }
}

static void ApplyGlow() {
    static bool wasOn = false;
    if (!g_clientBase) return;
    if (!g_settings.glowEnabled && !wasOn) return;

    uintptr_t entityList = Read<uintptr_t>(g_clientBase + offsets::dwEntityList);
    uintptr_t localController = Read<uintptr_t>(g_clientBase + offsets::dwLocalPlayerController);
    uintptr_t localPawn = Read<uintptr_t>(g_clientBase + offsets::dwLocalPlayerPawn);
    if (!entityList || !localPawn) return;
    int localTeam = Read<uint8_t>(localPawn + netvars::m_iTeamNum);
    int localIdx = GetLocalIndex(entityList, localController);

    for (int i = 1; i <= 64; i++) {
        uintptr_t controller = GetEntityByIndex(entityList, i);
        if (!controller || controller == localController) continue;
        uint32_t h = Read<uint32_t>(controller + netvars::m_hPlayerPawn);
        if (!h || h == 0xFFFFFFFF) continue;
        uintptr_t pawn = GetEntityByIndex(entityList, h & 0x7FFF);
        if (!pawn || pawn == localPawn) continue;

        bool alive = Read<int>(pawn + netvars::m_iHealth) > 0;
        bool enemy = Read<uint8_t>(pawn + netvars::m_iTeamNum) != localTeam;
        bool want = g_settings.glowEnabled && alive && (enemy || g_settings.glowTeammates);
        if (!want) { SetGlow(pawn, false, ImVec4()); continue; }

        ImVec4 c;
        if (g_settings.glowRainbow) c = Rainbow(g_settings.rainbowSpeed, i * 0.07f);
        else if (!enemy)
            c = ImVec4(g_settings.glowTeamColor[0], g_settings.glowTeamColor[1], g_settings.glowTeamColor[2], 1.f);
        else if (IsVisibleTo(pawn, localIdx))
            c = ImVec4(g_settings.espVisibleColor[0], g_settings.espVisibleColor[1], g_settings.espVisibleColor[2], 1.f);
        else
            c = ImVec4(g_settings.espHiddenColor[0], g_settings.espHiddenColor[1], g_settings.espHiddenColor[2], 1.f);
        SetGlow(pawn, true, c);
    }
    wasOn = g_settings.glowEnabled;
}

static bool g_aimHasTarget = false;

static Vec3 GetViewAngles() {
    // YÃ¶ntem 1: CSGOInput pointer Ã¼zerinden
    uintptr_t csgoInput = Read<uintptr_t>(g_clientBase + offsets::dwCSGOInput);
    if (csgoInput) {
        // ViewAngles CSGOInput+0x688 offset'inde (dwViewAngles - dwCSGOInput arasÄ±ndaki fark sabit deÄŸil,
        // ama genelde dwViewAngles doÄŸrudan client base'e gÃ¶re Ã§alÄ±ÅŸÄ±r)
    }

    // YÃ¶ntem 2: DoÄŸrudan client base + dwViewAngles
    return Read<Vec3>(g_clientBase + offsets::dwViewAngles);
}

static void SetViewAngles(const Vec3& angles) {
    // DoÄŸrudan yaz
    Write<Vec3>(g_clientBase + offsets::dwViewAngles, angles);
}

// ============================================================
// ESP rendering â€” ImGui ForegroundDrawList (overlay window'a gerek yok!)
// ============================================================
static void RenderESP(float screenW, float screenH) {
    if (!g_settings.espEnabled || !g_clientBase) return;

    ImDrawList* drawList = ImGui::GetForegroundDrawList();
    if (!drawList) return;

    uintptr_t entityList = Read<uintptr_t>(g_clientBase + offsets::dwEntityList);
    if (!entityList) {
        snprintf(g_dbgLastError, sizeof(g_dbgLastError), "EntityList = NULL (0x%llX)", (unsigned long long)(g_clientBase + offsets::dwEntityList));
        return;
    }

    uintptr_t localController = Read<uintptr_t>(g_clientBase + offsets::dwLocalPlayerController);
    uintptr_t localPawn = Read<uintptr_t>(g_clientBase + offsets::dwLocalPlayerPawn);

    if (!localPawn) {
        snprintf(g_dbgLastError, sizeof(g_dbgLastError), "LocalPawn = NULL (maÃ§ta deÄŸilsin?)");
        return;
    }

    int localTeam = Read<uint8_t>(localPawn + netvars::m_iTeamNum);
    ViewMatrix_t viewMatrix = Read<ViewMatrix_t>(g_clientBase + offsets::dwViewMatrix);

    // ViewMatrix doÄŸrulama: eÄŸer tamamen 0 ise Ã§alÄ±ÅŸmaz
    if (viewMatrix.m[3][3] == 0.0f && viewMatrix.m[0][0] == 0.0f) {
        snprintf(g_dbgLastError, sizeof(g_dbgLastError), "ViewMatrix tamamen 0!");
        return;
    }

    int playersFound = 0; int localIdx = GetLocalIndex(entityList, localController);
    int playersDrawn = 0;

    for (int i = 1; i <= 64; i++) {
        uintptr_t controller = GetEntityByIndex(entityList, i);
        if (!controller || controller == localController) continue;

        // Alive kontrolÃ¼
        bool isAlive = Read<bool>(controller + netvars::m_bPawnIsAlive);
        if (!isAlive) continue;

        // Pawn handle -> pawn pointer
        uint32_t pawnHandle = Read<uint32_t>(controller + netvars::m_hPlayerPawn);
        if (!pawnHandle || pawnHandle == 0xFFFFFFFF) continue;

        uintptr_t pawn = GetEntityByIndex(entityList, pawnHandle & 0x7FFF);
        if (!pawn || pawn == localPawn) continue;

        // Team check
        int team = Read<uint8_t>(pawn + netvars::m_iTeamNum);
        bool isEnemy = (team != localTeam);
        if (g_settings.espTeamCheck && !isEnemy) continue;

        // Health & lifestate
        int health = Read<int>(pawn + netvars::m_iHealth);
        if (health <= 0) continue;
        uint8_t lifeState = Read<uint8_t>(pawn + netvars::m_lifeState);
        if (lifeState != 0) continue;

        // Dormant check
        uintptr_t sceneNode = Read<uintptr_t>(pawn + netvars::m_pGameSceneNode);
        if (!sceneNode) continue;
        bool isDormant = Read<bool>(sceneNode + netvars::m_bDormant);
        if (isDormant) continue;

        playersFound++;

        // Pozisyonlar
        Vec3 origin = Read<Vec3>(sceneNode + netvars::m_vecAbsOrigin);
        if (origin.isZero()) continue;

        Vec3 headPos = GetHeadPos(pawn);
        if (headPos.isZero()) {
            headPos = origin;
            headPos.z += 72.0f; // oyuncu yÃ¼ksekliÄŸi tahmini
        }

        // WorldToScreen
        Vec3 screenFeet, screenHead;
        if (!WorldToScreen(origin, viewMatrix, screenFeet, screenW, screenH)) continue;

        Vec3 headAbove = headPos;
        headAbove.z += 8.0f;
        if (!WorldToScreen(headAbove, viewMatrix, screenHead, screenW, screenH)) continue;

        // Box hesaplama
        float boxH = screenFeet.y - screenHead.y;
        if (boxH < 4.0f) continue; // Ã§ok kÃ¼Ã§Ã¼k = Ã§ok uzak
        float boxW = boxH * 0.45f;
        float boxX = screenHead.x - boxW * 0.5f;
        float boxY = screenHead.y;

        playersDrawn++;

        ImU32 boxColorU32;
        ImVec4 espCol;
        if (g_settings.espRainbow) espCol = Rainbow(g_settings.rainbowSpeed, i * 0.07f);
        else if (!isEnemy) espCol = ImVec4(g_settings.espTeamColor[0], g_settings.espTeamColor[1], g_settings.espTeamColor[2], 1.f);
        else if (g_settings.espVisColors) {
            bool vis = IsVisibleTo(pawn, localIdx);
            const float* c = vis ? g_settings.espVisibleColor : g_settings.espHiddenColor;
            espCol = ImVec4(c[0], c[1], c[2], 1.f);
        }
        else espCol = ImVec4(g_settings.espBoxColor[0], g_settings.espBoxColor[1], g_settings.espBoxColor[2], 1.f);
        boxColorU32 = ImGui::ColorConvertFloat4ToU32(espCol);

        // Chams: iskelet uzerinden kalin dolgu silueti
        if (g_settings.chamsEnabled) {
            ImVec4 cc = g_settings.chamsRainbow ? Rainbow(g_settings.rainbowSpeed, i * 0.07f + 0.5f) : espCol;
            cc.w = g_settings.chamsAlpha;
            ImU32 chamU32 = ImGui::ColorConvertFloat4ToU32(cc);
            struct Seg { int a, b; float w; };
            static const Seg kSegs[] = {
                {6,5,0.045f}, {5,4,0.115f}, {4,2,0.120f}, {2,0,0.110f},
                {5,8,0.050f}, {8,9,0.042f}, {9,10,0.035f},
                {5,13,0.050f}, {13,14,0.042f}, {14,15,0.035f},
                {0,22,0.065f}, {22,23,0.052f}, {23,24,0.042f},
                {0,25,0.065f}, {25,26,0.052f}, {26,27,0.042f} };
            for (const Seg& sg : kSegs) {
                Vec3 a = GetBonePos(pawn, sg.a), b = GetBonePos(pawn, sg.b);
                if (a.isZero() || b.isZero()) continue;
                Vec3 sa, sb;
                if (!WorldToScreen(a, viewMatrix, sa, screenW, screenH)) continue;
                if (!WorldToScreen(b, viewMatrix, sb, screenW, screenH)) continue;
                float w = boxH * sg.w; if (w < 1.5f) w = 1.5f;
                float dx = sb.x - sa.x, dy = sb.y - sa.y;
                float len = sqrtf(dx * dx + dy * dy);
                if (len > 0.5f) {
                    float px = -dy / len * w, py = dx / len * w;
                    drawList->AddQuadFilled(ImVec2(sa.x + px, sa.y + py), ImVec2(sb.x + px, sb.y + py),
                                            ImVec2(sb.x - px, sb.y - py), ImVec2(sa.x - px, sa.y - py), chamU32);
                }
                drawList->AddCircleFilled(ImVec2(sa.x, sa.y), w, chamU32, 16);
                drawList->AddCircleFilled(ImVec2(sb.x, sb.y), w, chamU32, 16);
            }
            Vec3 hb = GetBonePos(pawn, 6), hs;
            if (!hb.isZero() && WorldToScreen(hb, viewMatrix, hs, screenW, screenH))
                drawList->AddCircleFilled(ImVec2(hs.x, hs.y), boxH * 0.075f, chamU32, 24);
        }

        // Box ESP
        if (g_settings.espBox) {
            // Outline (siyah)
            drawList->AddRect(ImVec2(boxX - 1, boxY - 1), ImVec2(boxX + boxW + 1, boxY + boxH + 1),
                IM_COL32(0, 0, 0, 200), 0.0f, 0, 3.0f);
            // Ana Ã§erÃ§eve
            drawList->AddRect(ImVec2(boxX, boxY), ImVec2(boxX + boxW, boxY + boxH),
                boxColorU32, 0.0f, 0, 1.5f);
        }

        // Ä°sim ESP
        if (g_settings.espName) {
            uintptr_t namePtr = Read<uintptr_t>(controller + netvars::m_sSanitizedPlayerName);
            char nameBuffer[128]{};
            if (namePtr && IsValidPtr(namePtr)) {
                for (int c = 0; c < 127; c++) {
                    char ch = Read<char>(namePtr + c);
                    nameBuffer[c] = ch;
                    if (ch == '\0') break;
                }
            }
            if (nameBuffer[0]) {
                ImVec2 textSize = ImGui::CalcTextSize(nameBuffer);
                float nameX = screenHead.x - textSize.x * 0.5f;
                float nameY = boxY - textSize.y - 3.0f;
                drawList->AddText(ImVec2(nameX + 1, nameY + 1), IM_COL32(0, 0, 0, 220), nameBuffer);
                drawList->AddText(ImVec2(nameX, nameY),
                    ImGui::ColorConvertFloat4ToU32(ImVec4(g_settings.espNameColor[0], g_settings.espNameColor[1], g_settings.espNameColor[2], g_settings.espNameColor[3])),
                    nameBuffer);
            }
        }

        // HP Bar (sol)
        if (g_settings.espHealthBar) {
            float barW = 3.0f;
            float barX = boxX - barW - 3.0f;
            float healthFrac = (float)health / 100.0f;
            if (healthFrac > 1.0f) healthFrac = 1.0f;
            float filledH = boxH * healthFrac;
            drawList->AddRectFilled(ImVec2(barX - 1, boxY - 1), ImVec2(barX + barW + 1, boxY + boxH + 1), IM_COL32(0, 0, 0, 180));
            float r = (1.0f - healthFrac);
            float g = healthFrac;
            drawList->AddRectFilled(ImVec2(barX, boxY + boxH - filledH), ImVec2(barX + barW, boxY + boxH),
                ImGui::ColorConvertFloat4ToU32(ImVec4(r, g, 0.0f, 1.0f)));
        }

        // HP text
        if (g_settings.espHealth) {
            char hpText[16];
            snprintf(hpText, sizeof(hpText), "%d HP", health);
            drawList->AddText(ImVec2(boxX + boxW + 4 + 1, boxY + 1), IM_COL32(0, 0, 0, 220), hpText);
            drawList->AddText(ImVec2(boxX + boxW + 4, boxY), IM_COL32(0, 255, 0, 255), hpText);
        }

        // Armor text
        if (g_settings.espArmor) {
            int armor = Read<int>(pawn + netvars::m_ArmorValue);
            if (armor > 0) {
                char armorText[16];
                snprintf(armorText, sizeof(armorText), "%d AP", armor);
                drawList->AddText(ImVec2(boxX + boxW + 4 + 1, boxY + 15), IM_COL32(0, 0, 0, 220), armorText);
                drawList->AddText(ImVec2(boxX + boxW + 4, boxY + 14), IM_COL32(128, 128, 255, 255), armorText);
            }
        }

        // Snaplines
        if (g_settings.espSnaplines) {
            drawList->AddLine(ImVec2(screenW * 0.5f, screenH), ImVec2(screenFeet.x, screenFeet.y), boxColorU32, 1.0f);
        }
    }

    g_dbgPlayersFound = playersFound;
    g_dbgPlayersDrawn = playersDrawn;
    if (playersFound > 0 && playersDrawn > 0) {
        snprintf(g_dbgLastError, sizeof(g_dbgLastError), "OK - %d oyuncu cizildi", playersDrawn);
    }
    else if (playersFound > 0 && playersDrawn == 0) {
        snprintf(g_dbgLastError, sizeof(g_dbgLastError), "W2S basarisiz (%d oyuncu bulundu)", playersFound);
    }
    else {
        snprintf(g_dbgLastError, sizeof(g_dbgLastError), "Dusman bulunamadi (team=%d)", localTeam);
    }
}

// ============================================================
// Aimbot
// ============================================================
static void RunAimbot() {
    g_aimHasTarget = false;
    if (!g_settings.aimbotEnabled || !g_clientBase || g_menuVisible) return;
    if (g_settings.aimbotRequireKey && !(GetAsyncKeyState(g_settings.aimbotKey) & 0x8000)) return;

    uintptr_t entityList = Read<uintptr_t>(g_clientBase + offsets::dwEntityList);
    uintptr_t localController = Read<uintptr_t>(g_clientBase + offsets::dwLocalPlayerController);
    uintptr_t localPawn = Read<uintptr_t>(g_clientBase + offsets::dwLocalPlayerPawn);
    if (!entityList || !localController || !localPawn) return;

    int localTeam = Read<uint8_t>(localPawn + netvars::m_iTeamNum);

    int aimLocalIdx = GetLocalIndex(entityList, localController);
    // Eye position
    Vec3 localOrigin = GetEntityOrigin(localPawn);
    Vec3 localViewOffset = Read<Vec3>(localPawn + netvars::m_vecViewOffset);
    Vec3 eyePos = localOrigin + localViewOffset;

    Vec3 viewAngles = GetViewAngles();

    // Recoil punch
    Vec3 punchAngle{};
    if (g_settings.aimbotRCS) {
        uintptr_t aimPunchServices = Read<uintptr_t>(localPawn + netvars::m_pAimPunchServices);
        if (aimPunchServices && IsValidPtr(aimPunchServices)) {
            punchAngle = Read<Vec3>(aimPunchServices + netvars::m_unpredictableBaseAngle);
        }
    }

    float bestFov = g_settings.aimbotFov;
    Vec3 bestAngle{};
    bool found = false;

    for (int i = 1; i <= 64; i++) {
        uintptr_t controller = GetEntityByIndex(entityList, i);
        if (!controller || controller == localController) continue;

        bool isAlive = Read<bool>(controller + netvars::m_bPawnIsAlive);
        if (!isAlive) continue;

        uint32_t pawnHandle = Read<uint32_t>(controller + netvars::m_hPlayerPawn);
        if (!pawnHandle || pawnHandle == 0xFFFFFFFF) continue;

        uintptr_t pawn = GetEntityByIndex(entityList, pawnHandle & 0x7FFF);
        if (!pawn || pawn == localPawn) continue;

        if (g_settings.aimbotTeamCheck) {
            int team = Read<uint8_t>(pawn + netvars::m_iTeamNum);
            if (team == localTeam) continue;
        }

        int health = Read<int>(pawn + netvars::m_iHealth);
        if (health <= 0) continue;
        uint8_t lifeState = Read<uint8_t>(pawn + netvars::m_lifeState);
        if (lifeState != 0) continue;

        uintptr_t sceneNode = Read<uintptr_t>(pawn + netvars::m_pGameSceneNode);
        if (!sceneNode) continue;
        bool isDormant = Read<bool>(sceneNode + netvars::m_bDormant);
        if (isDormant) continue;

        if (g_settings.aimbotVisCheck && !IsVisibleTo(pawn, aimLocalIdx)) continue;
        Vec3 targetPos;
        if (g_settings.aimbotBone == 6) {
            targetPos = GetHeadPos(pawn);
        }
        else {
            targetPos = GetBonePos(pawn, g_settings.aimbotBone);
            if (targetPos.isZero()) {
                Vec3 origin = GetEntityOrigin(pawn);
                targetPos = origin;
                targetPos.z += 50.0f; // gÃ¶ÄŸÃ¼s yÃ¼ksekliÄŸi tahmini
            }
        }
        if (targetPos.isZero()) continue;

        Vec3 aimAngle = CalcAngle(eyePos, targetPos);

        // RCS
        Vec3 compensated = aimAngle;
        if (g_settings.aimbotRCS) {
            compensated.x -= punchAngle.x * 2.0f;
            compensated.y -= punchAngle.y * 2.0f;
            ClampAngles(compensated);
        }

        float fov = GetFov(viewAngles, compensated);
        if (fov < bestFov) {
            bestFov = fov;
            bestAngle = compensated;
            found = true;
        }
    }

    g_aimHasTarget = found;
    if (found) {
        Vec3 delta;
        delta.x = bestAngle.x - viewAngles.x;
        delta.y = bestAngle.y - viewAngles.y;
        if (delta.y > 180.0f) delta.y -= 360.0f;
        if (delta.y < -180.0f) delta.y += 360.0f;

        float smooth = g_settings.aimbotSmooth;
        if (smooth < 1.0f) smooth = 1.0f;

        Vec3 finalAngle;
        finalAngle.x = viewAngles.x + delta.x / smooth;
        finalAngle.y = viewAngles.y + delta.y / smooth;
        finalAngle.z = 0.0f;
        ClampAngles(finalAngle);

        SetViewAngles(finalAngle);
    }
}

// ============================================================
// hooks
// ============================================================
// ============================================================
// FOV cemberi
// ============================================================
static void DrawAimFov(float w, float h) {
    if (!g_settings.aimbotEnabled || !g_settings.aimbotDrawFov) return;
    // CS2 yatay FOV: 4:3'te 90 derece, genis ekranda buyur
    float hfov = 2.0f * atanf(tanf(45.0f * DEG2RAD) * (w / h) / (4.0f / 3.0f));
    float r = tanf(g_settings.aimbotFov * DEG2RAD) / tanf(hfov * 0.5f) * (w * 0.5f);
    if (r < 2.0f) r = 2.0f;

    ImVec4 c;
    if (g_aimHasTarget) c = ImVec4(g_settings.fovLockedColor[0], g_settings.fovLockedColor[1], g_settings.fovLockedColor[2], g_settings.fovLockedColor[3]);
    else if (g_settings.fovRainbow) c = Rainbow(g_settings.rainbowSpeed);
    else c = ImVec4(g_settings.fovColor[0], g_settings.fovColor[1], g_settings.fovColor[2], g_settings.fovColor[3]);

    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImVec2 ctr(w * 0.5f, h * 0.5f);
    if (g_settings.fovFilled) {
        ImVec4 f = c; f.w = 0.12f;
        dl->AddCircleFilled(ctr, r, ImGui::ColorConvertFloat4ToU32(f), 96);
    }
    dl->AddCircle(ctr, r + 1.0f, IM_COL32(0, 0, 0, 160), 96, 3.0f);
    dl->AddCircle(ctr, r, ImGui::ColorConvertFloat4ToU32(c), 96, 1.6f);
}

// ============================================================
// Menu yardimcilari
// ============================================================
static void Tip(const char* text) {
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", text);
}
static void Section(const char* title) {
    ImGui::Spacing();
    ImGui::TextColored(ImVec4(0.65f, 0.35f, 1.0f, 1.0f), "%s", title);
    ImGui::Separator();
}
static std::string CfgPath() {
    char p[MAX_PATH]{};
    DWORD n = GetEnvironmentVariableA("USERPROFILE", p, MAX_PATH);
    std::string s = (n > 0 && n < MAX_PATH) ? std::string(p) + "\\Documents" : std::string(".");
    return s + "\\cs2int.cfg";
}
static bool SaveConfig() {
    FILE* f = nullptr;
    if (fopen_s(&f, CfgPath().c_str(), "wb") != 0 || !f) return false;
    uint32_t magic = 0x43324931, size = (uint32_t)sizeof(Settings);
    fwrite(&magic, 4, 1, f); fwrite(&size, 4, 1, f); fwrite(&g_settings, sizeof(Settings), 1, f);
    fclose(f);
    return true;
}
static bool LoadConfig() {
    FILE* f = nullptr;
    if (fopen_s(&f, CfgPath().c_str(), "rb") != 0 || !f) return false;
    uint32_t magic = 0, size = 0;
    bool ok = fread(&magic, 4, 1, f) == 1 && fread(&size, 4, 1, f) == 1 &&
              magic == 0x43324931 && size == sizeof(Settings);
    if (ok) ok = fread(&g_settings, sizeof(Settings), 1, f) == 1;
    fclose(f);
    return ok;
}
static void ColorRow(const char* label, float* col, const char* tip) {
    ImGui::ColorEdit4(label, col, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar);
    Tip(tip);
}

// ============================================================
// Menu
// ============================================================
static void RenderMenu() {
    ImGuiIO& io = ImGui::GetIO();
    static char status[96] = "";
    ImGui::SetNextWindowSize(ImVec2(500, 560), ImGuiCond_FirstUseEver);
    ImGui::Begin("CS2 Internal", &g_menuVisible, ImGuiWindowFlags_NoCollapse);

    // Ust cubuk: hizli acma/kapama
    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.f), "Hizli ac/kapa  |  FPS %.0f", io.Framerate);
    ImGui::Checkbox("ESP##q", &g_settings.espEnabled);       ImGui::SameLine();
    ImGui::Checkbox("Chams##q", &g_settings.chamsEnabled);   ImGui::SameLine();
    ImGui::Checkbox("Glow##q", &g_settings.glowEnabled);     ImGui::SameLine();
    ImGui::Checkbox("Aimbot##q", &g_settings.aimbotEnabled);
    ImGui::Separator();

    if (ImGui::BeginTabBar("##tabs")) {

        // ---------------- GORSEL ----------------
        if (ImGui::BeginTabItem("Gorsel")) {
            Section("ESP ogeleri");
            ImGui::Checkbox("Kutu", &g_settings.espBox);           ImGui::SameLine(160);
            ImGui::Checkbox("Isim", &g_settings.espName);          ImGui::SameLine(300);
            ImGui::Checkbox("Can cubugu", &g_settings.espHealthBar);
            ImGui::Checkbox("Can yazisi", &g_settings.espHealth);  ImGui::SameLine(160);
            ImGui::Checkbox("Zirh", &g_settings.espArmor);         ImGui::SameLine(300);
            ImGui::Checkbox("Cizgi", &g_settings.espSnaplines);
            Tip("Ekranin altindan oyunculara cizgi cizer");

            Section("Filtre");
            ImGui::Checkbox("Sadece dusmanlari goster", &g_settings.espTeamCheck);
            Tip("Kapatirsan takim arkadaslarin da cizilir");

            Section("Renkler");
            ImGui::Checkbox("Gorunen / gizli renk", &g_settings.espVisColors);
            Tip("Dusman gorus alanindaysa 'Gorunen', duvar arkasindaysa 'Gizli' renk kullanilir");
            ColorRow("Gorunen", g_settings.espVisibleColor, "Dusman gorunuyorken");
            ImGui::SameLine(160);
            ColorRow("Gizli", g_settings.espHiddenColor, "Dusman duvar arkasindayken");
            ColorRow("Takim", g_settings.espTeamColor, "Takim arkadaslari");
            ImGui::SameLine(160);
            ColorRow("Isim", g_settings.espNameColor, "Isim yazisi rengi");

            Section("Rainbow");
            ImGui::Checkbox("Rainbow ESP", &g_settings.espRainbow);
            Tip("Kutu ve cizgiler gokkusagi renklerinde akar");
            ImGui::SliderFloat("Rainbow hizi", &g_settings.rainbowSpeed, 0.05f, 2.0f, "%.2f");
            ImGui::EndTabItem();
        }

        // ---------------- CHAMS / GLOW ----------------
        if (ImGui::BeginTabItem("Chams / Glow")) {
            Section("Chams (dolgu govde)");
            ImGui::Checkbox("Chams aktif", &g_settings.chamsEnabled);
            Tip("Oyuncu govdesini duvarlarin arkasindan bile dolu renkli siluet olarak cizer");
            ImGui::Checkbox("Rainbow chams", &g_settings.chamsRainbow);
            ImGui::SliderFloat("Saydamlik", &g_settings.chamsAlpha, 0.1f, 1.0f, "%.2f");
            Tip("1.0 = tamamen dolu, dusuk deger = saydam");

            Section("Glow (oyunun kendi parlamasi)");
            ImGui::Checkbox("Glow aktif", &g_settings.glowEnabled);
            ImGui::Checkbox("Rainbow glow", &g_settings.glowRainbow);
            ImGui::Checkbox("Takim arkadaslarina da glow", &g_settings.glowTeammates);
            Tip("Acikken takimdakiler 'Takim glow' renginde parlar");
            ColorRow("Takim glow", g_settings.glowTeamColor, "Takim arkadaslarinin glow rengi");
            ImGui::TextDisabled("Dusman glow rengi: Gorsel sekmesindeki Gorunen/Gizli");
            ImGui::SliderFloat("Rainbow hizi##g", &g_settings.rainbowSpeed, 0.05f, 2.0f, "%.2f");
            ImGui::EndTabItem();
        }

        // ---------------- AIMBOT ----------------
        if (ImGui::BeginTabItem("Aimbot")) {
            Section("Genel");
            ImGui::Checkbox("Aimbot aktif", &g_settings.aimbotEnabled);
            ImGui::Checkbox("Tus gerektir", &g_settings.aimbotRequireKey);
            Tip("Kapaliyken tus gerekmez: FOV cemberine giren dusmana otomatik kilitlenir");
            if (g_settings.aimbotRequireKey) {
                const char* keyNames[] = { "Sol Alt", "Sol Shift", "Sol Ctrl", "Sag Tik", "X1 Mouse", "X2 Mouse" };
                int keyValues[] = { VK_LMENU, VK_LSHIFT, VK_LCONTROL, VK_RBUTTON, VK_XBUTTON1, VK_XBUTTON2 };
                int cur = 0;
                for (int k = 0; k < 6; k++) if (g_settings.aimbotKey == keyValues[k]) { cur = k; break; }
                if (ImGui::Combo("Tus", &cur, keyNames, 6)) g_settings.aimbotKey = keyValues[cur];
            }
            ImGui::Checkbox("Gorus kontrolu (duvar arkasina kilitlenme)", &g_settings.aimbotVisCheck);
            Tip("Sadece gorebildigin dusmanlara nisan alir");
            ImGui::Checkbox("Sadece dusman", &g_settings.aimbotTeamCheck);

            Section("Hassasiyet");
            ImGui::SliderFloat("FOV (derece)", &g_settings.aimbotFov, 1.0f, 30.0f, "%.1f");
            Tip("Nisan noktasi etrafindaki cemberin buyuklugu");
            ImGui::SliderFloat("Yumusaklik", &g_settings.aimbotSmooth, 1.0f, 20.0f, "%.1f");
            Tip("1 = aninda kilitlenir, yuksek deger = yavas ve dogal");
            const char* boneNames[] = { "Kafa", "Boyun", "Gogus", "Karin" };
            int boneValues[] = { 6, 5, 4, 2 };
            int cb = 0;
            for (int b = 0; b < 4; b++) if (g_settings.aimbotBone == boneValues[b]) { cb = b; break; }
            if (ImGui::Combo("Hedef bolge", &cb, boneNames, 4)) g_settings.aimbotBone = boneValues[cb];
            ImGui::Checkbox("Geri tepme kontrolu (RCS)", &g_settings.aimbotRCS);

            Section("FOV cemberi");
            ImGui::Checkbox("Cemberi ciz", &g_settings.aimbotDrawFov);
            Tip("Ekran ortasinda aimbot FOV alanini gosterir; hedefe kilitlenince renk degisir");
            ImGui::Checkbox("Ici dolu", &g_settings.fovFilled);   ImGui::SameLine(160);
            ImGui::Checkbox("Rainbow", &g_settings.fovRainbow);
            ColorRow("Cember", g_settings.fovColor, "Normal cember rengi");
            ImGui::SameLine(160);
            ColorRow("Kilitli", g_settings.fovLockedColor, "Hedefe kilitliyken cember rengi");
            ImGui::TextColored(g_aimHasTarget ? ImVec4(0, 1, 0.2f, 1) : ImVec4(0.6f, 0.6f, 0.6f, 1),
                               g_aimHasTarget ? "Durum: hedefe kilitli" : "Durum: hedef yok");
            ImGui::EndTabItem();
        }

        // ---------------- AYARLAR ----------------
        if (ImGui::BeginTabItem("Ayarlar")) {
            Section("Ayar dosyasi");
            if (ImGui::Button("Kaydet", ImVec2(110, 0)))
                snprintf(status, sizeof(status), SaveConfig() ? "Kaydedildi: %s" : "Kaydedilemedi!", CfgPath().c_str());
            ImGui::SameLine();
            if (ImGui::Button("Yukle", ImVec2(110, 0)))
                snprintf(status, sizeof(status), LoadConfig() ? "Ayarlar yuklendi" : "Ayar dosyasi yok / uyumsuz");
            ImGui::SameLine();
            if (ImGui::Button("Varsayilana don", ImVec2(130, 0))) { g_settings = Settings(); snprintf(status, sizeof(status), "Varsayilan ayarlar yuklendi"); }
            if (status[0]) ImGui::TextColored(ImVec4(0.5f, 1.f, 0.5f, 1.f), "%s", status);
            ImGui::TextDisabled("Dosya: %s", CfgPath().c_str());

            Section("Kisayollar");
            ImGui::BulletText("INSERT  : menuyu ac / kapat");
            ImGui::BulletText("DELETE  : DLL'i oyundan cikar");
            ImGui::EndTabItem();
        }

        // ---------------- DEBUG ----------------
        if (ImGui::BeginTabItem("Debug")) {
            uintptr_t el = Read<uintptr_t>(g_clientBase + offsets::dwEntityList);
            uintptr_t lc = Read<uintptr_t>(g_clientBase + offsets::dwLocalPlayerController);
            uintptr_t lp = Read<uintptr_t>(g_clientBase + offsets::dwLocalPlayerPawn);
            ImGui::Text("client: %p  entityList: %p", (void*)g_clientBase, (void*)el);
            ImGui::Text("controller: %p  pawn: %p", (void*)lc, (void*)lp);
            ImGui::Text("Cizilen: %d / Bulunan: %d", g_dbgPlayersDrawn, g_dbgPlayersFound);
            ImGui::TextColored(g_dbgPlayersDrawn > 0 ? ImVec4(0, 1, 0, 1) : ImVec4(1, 0.5f, 0, 1), "Durum: %s", g_dbgLastError);
            int li = GetLocalIndex(el, lc);
            ImGui::Text("local index: %d", li);
            ImGui::Separator();
            for (int i = 1; i <= 64; i++) {
                uintptr_t c = GetEntityByIndex(el, i);
                if (!c || c == lc) continue;
                uint32_t h = Read<uint32_t>(c + netvars::m_hPlayerPawn);
                if (!h || h == 0xFFFFFFFF) continue;
                uintptr_t p = GetEntityByIndex(el, h & 0x7FFF);
                if (!p) continue;
                int hp = Read<int>(p + netvars::m_iHealth);
                if (hp <= 0) continue;
                uint32_t mask = Read<uint32_t>(p + netvars::m_entitySpottedState + netvars::m_bSpottedByMask);
                ImGui::Text("#%d hp=%d team=%d mask=%08X gorunuyor=%s", i, hp,
                            (int)Read<uint8_t>(p + netvars::m_iTeamNum), mask, IsVisibleTo(p, li) ? "EVET" : "hayir");
            }
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
}

static int g_frameCount = 0;

static HRESULT __stdcall hkPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
    if (!g_imguiReady) InitImGui(sc);

    if (g_imguiReady) {
        if (!g_rtv) CreateRenderTarget(sc);

        if (!g_clientBase) {
            g_clientBase = (uintptr_t)GetModuleHandleA("client.dll");
            if (g_clientBase) Log("[+] client.dll = %p", (void*)g_clientBase);
        }

        g_frameCount++;

        // Aimbot (her frame)
        RunAimbot();
        ApplyGlow();

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        ImGuiIO& io = ImGui::GetIO();
        io.MouseDrawCursor = g_menuVisible;

        float screenW = io.DisplaySize.x;
        float screenH = io.DisplaySize.y;

        // ESP â€” doÄŸrudan ForegroundDrawList Ã¼zerine Ã§iz (ayrÄ± pencere yok!)
        RenderESP(screenW, screenH);

        DrawAimFov(screenW, screenH);
        if (g_menuVisible) RenderMenu();

        ImGui::Render();

        ID3D11RenderTargetView* oldRTV = nullptr;
        ID3D11DepthStencilView* oldDSV = nullptr;
        g_context->OMGetRenderTargets(1, &oldRTV, &oldDSV);
        if (g_rtv) g_context->OMSetRenderTargets(1, &g_rtv, nullptr);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_context->OMSetRenderTargets(1, &oldRTV, oldDSV);
        if (oldRTV) oldRTV->Release();
        if (oldDSV) oldDSV->Release();
    }

    return g_origPresent(sc, sync, flags);
}

static HRESULT __stdcall hkResizeBuffers(IDXGISwapChain* sc, UINT n, UINT w, UINT h, DXGI_FORMAT fmt, UINT fl) {
    ReleaseRenderTarget();
    if (g_imguiReady) ImGui_ImplDX11_InvalidateDeviceObjects();
    HRESULT hr = g_origResizeBuffers(sc, n, w, h, fmt, fl);
    if (g_imguiReady) {
        ImGui_ImplDX11_CreateDeviceObjects();
        CreateRenderTarget(sc);
    }
    return hr;
}

static BOOL __stdcall hkClipCursor(const RECT* r) {
    if (g_menuVisible) return g_origClipCursor(nullptr);
    return g_origClipCursor(r);
}

// ============================================================
// dummy pencere
// ============================================================
static HWND CreateDummyWindow() {
    WNDCLASSEXA wc{};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = DefWindowProcA;
    wc.hInstance = GetModuleHandleA(nullptr);
    wc.lpszClassName = "cs2int_dummy";
    if (!RegisterClassExA(&wc)) {
        DWORD err = GetLastError();
        if (err != ERROR_CLASS_ALREADY_EXISTS) return nullptr;
    }
    return CreateWindowExA(0, "cs2int_dummy", "cs2int", WS_OVERLAPPED, 0, 0, 8, 8, nullptr, nullptr, wc.hInstance, nullptr);
}

static void DestroyDummyWindow(HWND hwnd) {
    if (hwnd) DestroyWindow(hwnd);
    UnregisterClassA("cs2int_dummy", GetModuleHandleA(nullptr));
}

// ============================================================
// hook setup
// ============================================================
static bool SetupHooks() {
    HWND dummyHwnd = CreateDummyWindow();
    if (!dummyHwnd) return false;

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 1;
    sd.BufferDesc.Width = 8;
    sd.BufferDesc.Height = 8;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = dummyHwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    ID3D11Device* dummyDev = nullptr;
    ID3D11DeviceContext* dummyCtx = nullptr;
    IDXGISwapChain* dummySc = nullptr;
    D3D_FEATURE_LEVEL fl{};

    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &sd, &dummySc, &dummyDev, &fl, &dummyCtx);
    Log("[+] D3D11CreateDeviceAndSwapChain hr=0x%08X", (unsigned)hr);

    if (FAILED(hr)) {
        hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0, D3D11_SDK_VERSION, &dummyDev, &fl, &dummyCtx);
        if (SUCCEEDED(hr) && dummyDev) {
            IDXGIDevice* dxgiDev = nullptr;
            IDXGIAdapter* adapter = nullptr;
            IDXGIFactory* factory = nullptr;
            if (SUCCEEDED(dummyDev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgiDev)) && dxgiDev) {
                dxgiDev->GetAdapter(&adapter);
                if (adapter) adapter->GetParent(__uuidof(IDXGIFactory), (void**)&factory);
                if (factory) hr = factory->CreateSwapChain(dummyDev, &sd, &dummySc);
            }
            if (factory) factory->Release();
            if (adapter) adapter->Release();
            if (dxgiDev) dxgiDev->Release();
        }
    }

    if (FAILED(hr) || !dummySc) {
        if (dummyCtx) dummyCtx->Release();
        if (dummyDev) dummyDev->Release();
        DestroyDummyWindow(dummyHwnd);
        return false;
    }

    void** vt = *(void***)dummySc;
    void* presentPtr = vt[8];
    void* resizePtr = vt[13];

    if (MH_CreateHook(presentPtr, &hkPresent, (LPVOID*)&g_origPresent) != MH_OK) { dummySc->Release(); dummyCtx->Release(); dummyDev->Release(); DestroyDummyWindow(dummyHwnd); return false; }
    if (MH_CreateHook(resizePtr, &hkResizeBuffers, (LPVOID*)&g_origResizeBuffers) != MH_OK) { dummySc->Release(); dummyCtx->Release(); dummyDev->Release(); DestroyDummyWindow(dummyHwnd); return false; }

    HMODULE u32 = GetModuleHandleA("user32.dll");
    if (u32) {
        void* clip = (void*)GetProcAddress(u32, "ClipCursor");
        if (clip) MH_CreateHook(clip, &hkClipCursor, (LPVOID*)&g_origClipCursor);
    }

    dummySc->Release();
    dummyCtx->Release();
    dummyDev->Release();
    DestroyDummyWindow(dummyHwnd);

    if (MH_EnableHook(MH_ALL_HOOKS) != MH_OK) return false;
    Log("[+] hooks aktif");
    return true;
}

// ============================================================
// shutdown
// ============================================================
static void Shutdown() {
    MH_DisableHook(MH_ALL_HOOKS);
    MH_Uninitialize();
    if (g_imguiReady) {
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        g_imguiReady = false;
    }
    if (g_origWndProc && g_window)
        SetWindowLongPtrA(g_window, GWLP_WNDPROC, (LONG_PTR)g_origWndProc);
    ReleaseRenderTarget();
    if (g_context) { g_context->Release(); g_context = nullptr; }
    if (g_device) { g_device->Release(); g_device = nullptr; }
}

// ============================================================
// thread
// ============================================================
static DWORD WINAPI MainThread(LPVOID lpParam) {
    HMODULE hMod = (HMODULE)lpParam;
    OpenLog();
    Log("[+] CS2-Internal ESP+Aimbot yuklendi (v2)");

    while (!GetModuleHandleA("client.dll")) Sleep(200);
    g_clientBase = (uintptr_t)GetModuleHandleA("client.dll");
    Log("[+] client.dll = %p", (void*)g_clientBase);

    // Biraz bekle â€” game entity system yÃ¼klensin
    Sleep(2000);

    if (MH_Initialize() != MH_OK) { Log("[-] MH_Initialize fail"); goto cleanup; }
    if (!SetupHooks()) { Log("[-] SetupHooks fail"); goto cleanup; }
    Log("[+] INSERT = menu, DELETE = unload");

    while (!(GetAsyncKeyState(VK_DELETE) & 0x8000)) Sleep(100);

cleanup:
    Log("[!] kapatiliyor");
    Shutdown();
    if (g_log) { fclose(g_log); g_log = nullptr; }
    FreeLibraryAndExitThread(hMod, 0);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hMod, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hMod);
        CreateThread(nullptr, 0, MainThread, hMod, 0, nullptr);
    }
    return TRUE;
}
